# Inventário de fontes e validação

Verificação documental realizada em 21/10/2026. Pesquisa pública não equivale a confirmação direta da empresa.

| Dado | Fonte consultada | Estado |
|---|---|---|
| Nome comercial Rotina Café Galeria | Site público da empresa | Publicado no site oficial |
| Endereço Rua Teresópolis, 90, Jardim dos Estados, Poços de Caldas–MG | Site público da empresa; inventário turístico municipal | Convergente, mas confirmar entrada e orientação de visita |
| Telefone (35) 3014-1402 | Site público da empresa e diretórios | Convergente |
| Instagram @rotinacafegaleria | Site oficial e URL informada | Publicado |
| Horário terça–sexta, 13h–19h | Site público e diretórios | Convergente |
| Horário sábado e domingo | Site oficial informa 9h–19h; alguns diretórios informam 9h30–19h | Divergência, confirmar |
| Segunda-feira | Diretórios apontam fechado; site oficial não publica esse dia | Confirmar |
| E-mail rotinacafegaleria@gmail.com.br | Site oficial | Publicado, mas domínio atípico e não validado; não usado como link |
| Waffle de pão de queijo, Torta Chalé, chás completos | Site oficial | Apresentados como especialidades; disponibilidade atual não confirmada |
| Produtos e preços do catálogo | PDF público hospedado no site, 2 páginas | Fonte histórica antiga; cada preço está marcado para confirmação |
| Fotos | URLs de imagens associadas ao site oficial | Origem oficial identificada; confirmar carregamento, direitos e permanência das URLs em produção |
| Avaliações | Diretórios públicos apresentam notas diferentes | Não incorporadas no site, para evitar exibir números inconsistentes |
| Delivery, reservas, pedido online, pagamentos digitais | Nenhuma confirmação oficial suficiente | Não anunciados |

## Fontes públicas
- Site da cafeteria: https://www.rotinapaes.com.br/rotinacafegaleria
- Cardápio PDF: https://www.rotinapaes.com.br/_files/ugd/53f795_f0ac695f10464127b536ea3fb6946759.pdf
- Instagram: https://www.instagram.com/rotinacafegaleria/
- Inventário turístico municipal: https://pocosdecaldas.mg.gov.br/tour/observatorio/arquivos/estudos_1_2024-12-26_12-14-15.pdf
- Diretório consultado para comparação de horários e divergências: https://restaurantguru.com.br/Cafe-Casa-da-Cultura-Pocos-de-Caldas

## Decisões editoriais
- Não se publicam notas nem depoimentos de clientes.
- Não se afirma acessibilidade, estacionamento, Wi-Fi, delivery, reservas ou pagamentos, por falta de confirmação direta atual.
- O catálogo contém valores do PDF antigo, sempre acompanhados de aviso visível e status interno `needs-confirmation`.
- Não foram incluídas bebidas alcoólicas no catálogo.
- A assinatura tipográfica de cabeçalho é provisória e não substitui o arquivo oficial de logotipo; obter arquivo vetorial ou PNG aprovado antes de produção.
