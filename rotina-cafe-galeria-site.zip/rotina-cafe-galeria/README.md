# Rotina Café Galeria — site editorial responsivo

Aplicação Next.js App Router + React + TypeScript, com catálogo pesquisável e filtrável, galeria ampliável, navegação responsiva, links de contato e rota, metadados SEO e JSON-LD para cafeteria.

## Requisitos
- Node.js 20.9+ (recomendado Node 22 LTS)
- npm

## Instalação e execução
```bash
npm install
npm run dev
```
Acesse `http://localhost:3000`.

## Build de produção
```bash
npm run lint
npm run test
npm run build
npm run start
```

## Publicação
1. Envie o repositório para GitHub.
2. Importe o repositório em Vercel ou hospedagem compatível com Next.js.
3. Configure `NEXT_PUBLIC_SITE_URL` com a URL canônica aprovada.
4. Publique e confira sitemap, robots, metadados e links externos.

## Dados do cardápio
O catálogo central está em `lib/menu.ts`. Todos os preços têm `priceStatus: 'needs-confirmation'` e a fonte associada porque foram transcritos de um PDF público antigo, consultado em 21/10/2026. **Não publicar valores como vigentes sem confirmação da empresa.** Edite uma única fonte de dados para alterar nomes, preços e descrições. As opções de chá 2 e 3 e o produto Caprese possuem divergências/ambiguidade anotadas no próprio catálogo.

## Pendências de validação comercial antes de produção
- Confirmar todos os preços e a disponibilidade de cada produto.
- Resolver a ambiguidade de preços/opções no PDF para Caprese e chás completos.
- Confirmar se o e-mail `rotinacafegaleria@gmail.com.br` é válido; não foi utilizado como link de contato.
- Confirmar o horário de sábado e domingo (site oficial diz 9h; diretórios variam entre 9h e 9h30).
- Confirmar segunda-feira; diretórios apontam fechamento, mas a página oficial não informa esse dia.
- Confirmar se a localização e a entrada de visita permanecem as mesmas; diretórios divergem sobre a fachada/entrada.
- Aprovar a identidade visual: o cabeçalho usa uma assinatura tipográfica provisória com ícone, não substitui o arquivo oficial do logotipo.
- Conferir carregamento e autorização das três imagens oficiais externas; caso URLs tenham sido alteradas, substituir pelos arquivos autorizados em `public/`.
- O iframe de mapa é uma integração externa e deve ser validado em produção.

## Limitações explícitas
- Não existe backend ou painel administrativo nesta entrega; catálogo local em TypeScript é a alternativa documentada.
- Não há formulário que simule envio. Contato é realizado por telefone e Instagram.
- O endereço de produção e o domínio canônico precisam ser confirmados pelo responsável pelo negócio.
- A performance e acessibilidade não podem ser consideradas aprovadas sem testes reais em ambiente publicado.
