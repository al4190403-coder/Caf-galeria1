import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import './globals.css';
export const metadata: Metadata = {
 title: { default: 'Rotina Café Galeria | Café, gastronomia e cultura em Poços de Caldas', template: '%s | Rotina Café Galeria' },
 description: 'Conheça a Rotina Café Galeria no IMS Poços de Caldas. Explore o cardápio de cafés, waffles, doces e especialidades e planeje sua visita.',
 metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://www.rotinapaes.com.br'),
 alternates: { canonical: '/rotinacafegaleria' },
 openGraph: { type: 'website', locale: 'pt_BR', title: 'Rotina Café Galeria', description: 'Um lugar para apreciar o tempo, o café e a cultura.', siteName: 'Rotina Café Galeria', images: [{url:'https://static.wixstatic.com/media/53f795_7c9baf266683496a8ce917726063a74c~mv2.jpg/v1/fill/w_1200,h_800,al_c,q_85/53f795_7c9baf266683496a8ce917726063a74c~mv2.jpg',width:1200,height:800,alt:'Rotina Café Galeria'}] },
 twitter: { card:'summary_large_image', title:'Rotina Café Galeria', description:'Café, gastronomia e cultura em Poços de Caldas.' },
};
export const viewport: Viewport = { width:'device-width', initialScale:1, themeColor:'#f5f0e7' };
export default function RootLayout({children}:{children:ReactNode}) { return <html lang="pt-BR"><body>{children}</body></html>; }
