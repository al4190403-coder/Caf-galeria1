import Site from '@/components/Site';
import { menuItems } from '@/lib/menu';
export default function Home(){
 const jsonLd = { '@context':'https://schema.org', '@type':'CafeOrCoffeeShop', name:'Rotina Café Galeria', url:'https://www.rotinapaes.com.br/rotinacafegaleria', telephone:'+55 35 3014-1402', address:{'@type':'PostalAddress',streetAddress:'Rua Teresópolis, 90',addressLocality:'Poços de Caldas',addressRegion:'MG',addressCountry:'BR'}, sameAs:['https://www.instagram.com/rotinacafegaleria/'], openingHoursSpecification:[{ '@type':'OpeningHoursSpecification',dayOfWeek:['Tuesday','Wednesday','Thursday','Friday'],opens:'13:00',closes:'19:00'},{'@type':'OpeningHoursSpecification',dayOfWeek:['Saturday','Sunday'],opens:'09:00',closes:'19:00'}], hasMenu:'https://www.rotinapaes.com.br/_files/ugd/53f795_f0ac695f10464127b536ea3fb6946759.pdf' };
 return <><script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(jsonLd).replace(/</g,'\\u003c')}}/><Site/><span className="sr-only">Catálogo com {menuItems.length} itens transcritos do cardápio público, com preços pendentes de confirmação.</span></>;
}
