import type { MetadataRoute } from 'next';
export default function sitemap(): MetadataRoute.Sitemap { return [{ url: 'https://www.rotinapaes.com.br/rotinacafegaleria', lastModified: new Date(), changeFrequency: 'monthly', priority: 1 }]; }
