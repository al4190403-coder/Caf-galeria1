import { describe, expect, it } from 'vitest';
import { brl, categories, menuItems } from '../lib/menu';
describe('catálogo do cardápio', () => {
 it('usa IDs únicos para todos os itens', () => { expect(new Set(menuItems.map(p => p.id)).size).toBe(menuItems.length); });
 it('mantém todas as categorias de produtos no filtro', () => { expect(categories[0]).toBe('Todas'); expect(categories).toContain('Cafés quentes'); expect(categories).toContain('Doces e sobremesas'); });
 it('marca os preços do catálogo como pendentes de confirmação', () => { expect(menuItems.every(p => p.priceStatus === 'needs-confirmation')).toBe(true); });
 it('formata moeda em padrão brasileiro', () => { expect(brl(6.5)).toContain('6,50'); expect(brl(20)).toContain('20,00'); });
 it('não inclui bebidas alcoólicas no catálogo público', () => { expect(menuItems.some(p => /cerveja|vinho|drink alcoólico/i.test(p.name))).toBe(false); });
});
